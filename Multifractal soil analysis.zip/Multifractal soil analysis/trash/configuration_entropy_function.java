// This method calculates the configuration entropy function.
// Black and white image is required.

// Import libraries
import ij.plugin.filter.PlugInFilter;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import ij.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import ij.text.*;
import ij.gui.*;
import ij.util.*;
import ij.io.*;
import ij.process.*;
import ij.measure.*;
import javax.imageio.ImageIO;
import static java.lang.Math.*;	

public class configuration_entropy_function{
	ImageProcessor ip;
	
	//double[][] Xnum;
	//double[][] denomMu;  
	//double[][] numalpha;  
	//double[][] numf;
	//double[] q;
	//boolean isstack;
	String str;
	//String path;

	// Final variables x e y
	public void out() {
		int woriginal  = ip.getWidth();						// width from the original image
		int horiginal  = ip.getHeight();
		int lmax = min(woriginal,horiginal);
		double[] lsize = new double[(int)lmax+1]; 
		Roi cuadradointeres;
		Rectangle roi;									// Region of
		Rectangle fullimage = ip.getRoi();
		double[] entropy = new double[(int)lmax+1];
		
	
		// Gliding Box bucle
		for (int n = 1; n<=lmax; n++){ // Para cada tamano l de subcuadrado
			IJ.log(""+(lmax-n));							// Show bucles left 
			lsize[n]   = n;
			int numpixel = (n);							// Size in pixels of ROIs
			int box      = 0;
			double boxnumbers  = (woriginal-n+1)*(horiginal-n+1);			// Number of box for gliding
			double[] measure_box  = new double[(int)boxnumbers];			// Aquí se guarda el numero de boxes						
			double numblackpixel;
			int counter = 0;
			int total_pixel = n*n;
			// Creating ROIs along image
			for (int y=fullimage.y; y<fullimage.y+fullimage.height-numpixel+1; y++){
				for (int x=fullimage.x; x<fullimage.x+fullimage.width-numpixel+1; x++){	
					cuadradointeres = new Roi(x, y, numpixel, numpixel);	// Creating size of ROI
					ip.setRoi(cuadradointeres);		    	// Fix ROI in the image
					roi = ip.getRoi();				// Processing ROI
					numblackpixel=0;
					// Counting pixels along roi 
					for (int yy=roi.y; yy<(roi.y+roi.height); yy++){		
						for (int xx=roi.x; xx<(roi.x+roi.width); xx++){
							if (ip.get(xx,yy) == 0){numblackpixel += +1;}

						}
					}
					
					measure_box[counter] = numblackpixel;	// Guarda el numero de black pixels
					counter +=1;

				}
			}
			double[] freq_distribution = new double[(int)total_pixel + 1];		// vector p(black_boxes)
			for (int pos = 0; pos<measure_box.length; pos++){
				freq_distribution[(int)measure_box[pos]] += 1;
			}
			//IJ.log("length" + freq_distribution.length);

			for (int dum = 0; dum<freq_distribution.length; dum++){ //Get the probabilities
				freq_distribution[dum] = (double)freq_distribution[dum]/(double)boxnumbers;
			}

			double local_entropy = 0;		
			for (int dum = 0; dum<freq_distribution.length; dum++){ // Calculate normalized entropy
				//IJ.log(""+freq_distribution[dum]);
				if (freq_distribution[dum] > 0){ // Para evitar log 0
					local_entropy += -(double)freq_distribution[dum] * (double)log(freq_distribution[dum]);
				}
			}
			local_entropy = (double)local_entropy/(double)log(n*n + 1);	//Normalizar la entropia
			//IJ.log("entropy " + local_entropy);
			entropy[n] = local_entropy;
		}
		// Get characteristic length
		double max_entropy = 0;
		int char_length = 0;
		for (int n = 1; n<=lmax; n++){
			if (entropy[n] > max_entropy){
				max_entropy = entropy[n];
				char_length = n;
			}
		}
		//IJ.log("char_length " + char_length);

		// Plot normalized entropy vs l
		PlotWindow.noGridLines = false; 						// draw grid lines
		Plot plot_entropy = new Plot("H*(l)", "l", "H*(l)", lsize, entropy);
		plot_entropy.setLimits(1, lsize[lsize.length-1], 0, 1.3 );
		plot_entropy.setLineWidth(2);								// Line width
		//plot3.addErrorBars(desvalphaq); 							// Errors bars
		plot_entropy.setColor(Color.red);							// line color
		plot_entropy.show();

		


























		//IJ.log(str);

		//table1.setPrecision(8);
		//table1.updateResults();
		//table1.setPrecision(8);


		//table1.show("Results");
		//IJ.selectWindow("Results");
		//IJ.save(path+"Results.txt");
		




	}
}
