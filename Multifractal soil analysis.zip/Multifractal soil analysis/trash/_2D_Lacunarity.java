// Ivan Gonzalez Torre

// Libraries import
import ij.plugin.filter.PlugInFilter;
import java.awt.*;
import ij.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import ij.process.*;
import ij.text.*;
import ij.gui.*;
import ij.util.*;
import ij.io.*;
import ij.process.*;
import ij.measure.*;
import static java.lang.Math.*;	

public class _2D_Lacunarity implements PlugInFilter {
public ImagePlus salida;
	public int setup(String arg, ImagePlus imp) {
		//if (imp.getProcessor().isInvertedLut()){
			//IJ.run("Invert LUT");
		//}
		return DOES_8G+DOES_16+DOES_32;						// Suports gray scale image
		
	}


	public void run(ImageProcessor ip) {

	// Plot tables and result
		lacunarity_function lacunarity_fun = new lacunarity_function();
		//String str = new String(" 2D Multifractal Box Counting method");
		lacunarity_fun.str = "hola";
		lacunarity_fun.ip = ip;
		//boolean isstack = false;
		//result.isstack = isstack;
		//result.epsilon = epsilon;
		//result.Xnum = Xnum;
		//result.denomMu = denomMu;
		//result.numalpha = numalpha;
		//result.numf = numf;
		//result.q = q;
		//result.path = path;
		lacunarity_fun.out();
		//time_end = System.currentTimeMillis();
		IJ.log("hola hola");
		IJ.log("hola hola");
		//IJ.log("The task has taken "+ ( time_end - time_start ) +" milliseconds");
	}
}
